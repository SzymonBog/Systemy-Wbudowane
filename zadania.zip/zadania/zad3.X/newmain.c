#pragma config POSCMOD = XT // XT Oscillator mode selected
#pragma config OSCIOFNC = ON // OSC2/CLKO/RC15 as port I/O (RC15)
#pragma config FCKSM = CSDCMD // Clock Switching and Monitor disabled
#pragma config FNOSC = PRI // Primary Oscillator (XT, HS, EC)
#pragma config IESO = ON // Int Ext Switch Over Mode enabled
// CONFIG1
#pragma config WDTPS = PS32768 // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128 // WDT Prescaler (1:128)
#pragma config WINDIS = ON // Watchdog Timer Window Mode disabled
#pragma config FWDTEN = OFF // Watchdog Timer disabled
#pragma config ICS = PGx2 // Emulator/debugger uses EMUC2/EMUD2
#pragma config GWRP = OFF // Writes to program memory allowed
#pragma config GCP = OFF // Code protection is disabled
#pragma config JTAGEN = OFF // JTAG port is disabled
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
#include <xc.h>
#include <libpic30.h>
#include <stdio.h>
#include <string.h>
#include "lcd.h"
#include "buttons.h"
#define TOTAL_TIME (30)
volatile unsigned int seconds = TOTAL_TIME;

int main(void) {
    unsigned int remainingSeconds1 = seconds;
    unsigned int remainingSeconds2 = seconds;
    char buffer[32];
    LCD_Initialize();
    int turn = 1;
    if (BUTTON_IsPressed ( BUTTON_S5 ) == true){
        while((remainingSeconds1 > 0)&(remainingSeconds2 > 0)) {
            if (BUTTON_IsPressed ( BUTTON_S3 ) == true) {
                turn = 2;
            } else if ((BUTTON_IsPressed ( BUTTON_S6 ) == true)) {
                turn = 1;
            } else if ((BUTTON_IsPressed ( BUTTON_S4 ) == true)) {
                break;
            }
            unsigned char minutes1 = remainingSeconds1 / 60;
            unsigned char secs1 = remainingSeconds1 % 60;
            unsigned char minutes2 = remainingSeconds2 / 60;
            unsigned char secs2 = remainingSeconds2 % 60;
            sprintf(buffer, " %02u:%02u    %02u:%02u", minutes1, secs1, minutes2, secs2);
            LCD_ClearScreen();
            LCD_PutString(buffer, strlen(buffer));
            __delay32(4000000);
            if(turn == 1){
                remainingSeconds1--;
            }
            else{
                remainingSeconds2--;
            }
        }
    }
    if(remainingSeconds1 == 0){
        sprintf(buffer, "gracz 1 - koniec czasu");
        LCD_ClearScreen();
        LCD_PutString(buffer, strlen(buffer));
        __delay32(4000000);
    }else if(remainingSeconds2 == 0){
        sprintf(buffer, "gracz 2 - koniec czasu");
        LCD_ClearScreen();
        LCD_PutString(buffer, strlen(buffer));
        __delay32(4000000);
    }else{
        sprintf(buffer, "koniec gry");
        LCD_ClearScreen();
        LCD_PutString(buffer, strlen(buffer));
    }
    
    return 0;
}